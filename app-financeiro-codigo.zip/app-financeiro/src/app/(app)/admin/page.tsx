import { verifyAdminSession } from "@/lib/dal";
import { withServiceMode } from "@/db/client";
import { listClientsForAdmin, type AdminClientRow, type UsageHealth } from "@/lib/queries/admin";
import { formatDateBR, formatDateTimeBR, formatYearMonthBR } from "@/lib/format";
import { approveClient, suspendClient, reactivateClient } from "@/app/actions/admin";
import { DueDateForm } from "./DueDateForm";

const STATUS_LABEL: Record<string, string> = {
  pending: "Aguardando aprovação",
  active: "Ativo",
  suspended: "Suspenso",
};

const STATUS_CLASS: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
  active: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300",
  suspended: "bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300",
};

const HEALTH_LABEL: Record<UsageHealth, string> = {
  ativo: "Ativo (7 dias)",
  baixo_uso: "Baixo uso (30 dias)",
  inativo: "Inativo (30+ dias)",
  nunca_acessou: "Nunca acessou",
};

const HEALTH_CLASS: Record<UsageHealth, string> = {
  ativo: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300",
  baixo_uso: "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
  inativo: "bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-400",
  nunca_acessou: "bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-400",
};

function Badge({ label, className }: { label: string; className: string }) {
  return <span className={`whitespace-nowrap rounded-full px-2 py-0.5 text-xs font-medium ${className}`}>{label}</span>;
}

function DueDateInfo({ client }: { client: AdminClientRow }) {
  if (!client.subscriptionDueDate) {
    return <span className="text-xs text-slate-400">sem vencimento definido</span>;
  }
  const days = client.daysUntilDue ?? 0;
  const overdue = days < 0;
  const dueSoon = days >= 0 && days <= 5;
  return (
    <span
      className={`text-xs ${
        overdue ? "font-semibold text-red-600 dark:text-red-400" : dueSoon ? "font-semibold text-amber-600 dark:text-amber-400" : "text-slate-500 dark:text-slate-400"
      }`}
    >
      {formatDateBR(client.subscriptionDueDate)} ({overdue ? `vencido há ${Math.abs(days)}d` : `em ${days}d`})
    </span>
  );
}

export default async function AdminPage() {
  await verifyAdminSession();

  // Cross-tenant de propósito: painel administrativo precisa ver todos os
  // clientes, não só o próprio admin — por isso service_mode em vez de
  // withRLS (ver src/db/client.ts e src/lib/dal.ts#verifyAdminSession, que
  // já confirmou acima que quem está pedindo é mesmo um admin).
  const clients = await withServiceMode(() => listClientsForAdmin());

  const totals = {
    total: clients.length,
    pending: clients.filter((c) => c.status === "pending").length,
    active: clients.filter((c) => c.status === "active").length,
    suspended: clients.filter((c) => c.status === "suspended").length,
    overdue: clients.filter((c) => c.status === "active" && c.daysUntilDue !== null && c.daysUntilDue < 0).length,
  };

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900 dark:text-slate-100">Painel administrativo</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Clientes, uso e mensalidade — aprove novos cadastros e controle o vencimento de cada um.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
        <SummaryCard label="Clientes" value={totals.total} />
        <SummaryCard label="Aguardando aprovação" value={totals.pending} accent={totals.pending > 0 ? "amber" : undefined} />
        <SummaryCard label="Ativos" value={totals.active} accent="emerald" />
        <SummaryCard label="Suspensos" value={totals.suspended} />
        <SummaryCard label="Mensalidade vencida" value={totals.overdue} accent={totals.overdue > 0 ? "red" : undefined} />
      </div>

      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <table className="w-full min-w-[900px] text-left text-sm">
          <thead className="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400 dark:border-slate-800">
            <tr>
              <th className="px-4 py-3 font-medium">Cliente</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Último acesso</th>
              <th className="px-4 py-3 font-medium">Saúde de uso</th>
              <th className="px-4 py-3 font-medium">Último fechamento</th>
              <th className="px-4 py-3 font-medium">Mensalidade</th>
              <th className="px-4 py-3 font-medium">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
            {clients.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center text-slate-400">
                  Nenhum cliente cadastrado ainda.
                </td>
              </tr>
            )}
            {clients.map((client) => (
              <tr key={client.id} className="align-top">
                <td className="px-4 py-3">
                  <div className="font-medium text-slate-800 dark:text-slate-100">{client.name || "(sem nome)"}</div>
                  <div className="text-xs text-slate-400">{client.email}</div>
                  {client.role === "admin" && (
                    <div className="mt-1">
                      <Badge label="admin" className="bg-slate-800 text-white dark:bg-slate-100 dark:text-slate-900" />
                    </div>
                  )}
                  <div className="mt-1 text-[11px] text-slate-400">Cadastro: {formatDateTimeBR(client.createdAt)}</div>
                </td>
                <td className="px-4 py-3">
                  <Badge label={STATUS_LABEL[client.status] ?? client.status} className={STATUS_CLASS[client.status] ?? ""} />
                </td>
                <td className="px-4 py-3 text-xs text-slate-500 dark:text-slate-400">
                  {client.lastLoginAt ? formatDateTimeBR(client.lastLoginAt) : "nunca acessou"}
                </td>
                <td className="px-4 py-3">
                  <Badge label={HEALTH_LABEL[client.usageHealth]} className={HEALTH_CLASS[client.usageHealth]} />
                </td>
                <td className="px-4 py-3 text-xs text-slate-500 dark:text-slate-400">
                  {client.lastClosedYearMonth ? formatYearMonthBR(client.lastClosedYearMonth) : "nunca fechou um mês"}
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-col gap-1.5">
                    <DueDateInfo client={client} />
                    <DueDateForm userId={client.id} currentValue={client.subscriptionDueDate} />
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-col gap-1.5">
                    {client.status === "pending" && (
                      <form action={approveClient}>
                        <input type="hidden" name="id" value={client.id} />
                        <button
                          type="submit"
                          className="w-full rounded-lg bg-emerald-600 px-3 py-1 text-xs font-semibold text-white hover:bg-emerald-700"
                        >
                          Aprovar acesso
                        </button>
                      </form>
                    )}
                    {client.status === "active" && client.role !== "admin" && (
                      <form action={suspendClient}>
                        <input type="hidden" name="id" value={client.id} />
                        <button
                          type="submit"
                          className="w-full rounded-lg border border-red-300 px-3 py-1 text-xs font-medium text-red-600 hover:bg-red-50 dark:border-red-900 dark:text-red-400 dark:hover:bg-red-950"
                        >
                          Suspender
                        </button>
                      </form>
                    )}
                    {client.status === "suspended" && (
                      <form action={reactivateClient}>
                        <input type="hidden" name="id" value={client.id} />
                        <button
                          type="submit"
                          className="w-full rounded-lg bg-emerald-600 px-3 py-1 text-xs font-semibold text-white hover:bg-emerald-700"
                        >
                          Reativar
                        </button>
                      </form>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function SummaryCard({ label, value, accent }: { label: string; value: number; accent?: "emerald" | "amber" | "red" }) {
  const accentClass =
    accent === "emerald"
      ? "text-emerald-700 dark:text-emerald-400"
      : accent === "amber"
        ? "text-amber-700 dark:text-amber-400"
        : accent === "red"
          ? "text-red-700 dark:text-red-400"
          : "text-slate-800 dark:text-slate-100";

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
      <div className={`text-2xl font-semibold ${accentClass}`}>{value}</div>
      <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{label}</div>
    </div>
  );
}
